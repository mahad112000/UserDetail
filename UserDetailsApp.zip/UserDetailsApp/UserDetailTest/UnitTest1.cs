using DataAccessLayer;
namespace UserDetailTest
{
    [TestClass]
    public class UnitTest1
    {

        [TestMethod]
        public async Task GetUsersTest()
        {
            var dataStore = new DataStore();
            var users = await dataStore.GetUsersAsync<IEnumerable<User>>();
            Assert.IsTrue(users.Count() > 0);
        }

        [TestMethod]
        public async Task PostUserTest()
        {
            var dataStore = new DataStore();
            var user = new User { name = "Mahad test", email = "xxxxx@testtest.com", gender = "Male", status = "active" };
            var addedMessage = await dataStore.PostUserAsync(user);
            Assert.Equals("Posted user successfully", addedMessage);
        }

    }
}