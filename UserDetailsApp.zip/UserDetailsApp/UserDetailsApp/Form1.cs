using DataAccessLayer;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using System.Runtime.CompilerServices;

namespace UserDetailsApp
{
    public partial class Form1 : Form
    {
        //public Form1()
        //{
        //    InitializeComponent();
        //}

        private readonly IDataStore dataStore;

        public Form1(IDataStore dataStore)
        {
            InitializeComponent();
            this.dataStore = dataStore;
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            var data = await dataStore.GetUsersAsync<IEnumerable<User>>();
            dataGridView1.Columns.Clear();
            dataGridView1.DataSource = data;


            DataGridViewButtonColumn addBtn = new DataGridViewButtonColumn();
            addBtn.Text = "Edit";
            addBtn.Name = "btnAdd";
            addBtn.UseColumnTextForButtonValue = true;
            dataGridView1.Columns.Add(addBtn);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dataGridView1.Columns["btnAdd"].Index)
            {
                MessageBox.Show(String.Format("Clicked! Row: {0}", e.RowIndex));
            }
        }


        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                using (var newUserForm = Program.ServiceProvider.GetRequiredService<NewUserForm>())
                    newUserForm.ShowDialog();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message);
            }
        }

        private async void btnSearch_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtUserName.Text))
            {
                MessageBox.Show("Please enter first name");
                return;
            }
            var users = await dataStore.GetUsersAsync<IEnumerable<User>>(txtUserName.Text);
            dataGridView1.Columns.Clear();
            dataGridView1.DataSource = users;
        }
    }
}