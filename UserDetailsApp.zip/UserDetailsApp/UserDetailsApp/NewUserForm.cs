﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace UserDetailsApp
{
    public partial class NewUserForm : Form
    {
        private readonly IDataStore dataStore;


        public NewUserForm(IDataStore dataStore)
        {
            InitializeComponent();
            this.dataStore = dataStore;
        }



        private async void btnSaveExit_Click(object sender, EventArgs e)
        {
            var posted = await SaveUser();
            MessageBox.Show(posted);
            this.Close();
        }

        private async Task<string> SaveUser()
        {
            if (txtName.Text == "" || txtEmail.Text == "")
            {
                MessageBox.Show("Name/Email can't be blank");
                return null;
            }
            var user = new User
            {
                name = txtName.Text,
                email = txtEmail.Text,
                gender = chkGender.SelectedItem.ToString(),
                status = chkStatus.SelectedItem.ToString()
            };
            return await dataStore.PostUserAsync(user);
        }
        private void NewUserForm_Load(object sender, EventArgs e)
        {
            chkGender.SelectedIndex = 1;
            chkStatus.SelectedIndex = 1;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private async void btnSaveContinue_Click(object sender, EventArgs e)
        {
            var posted = await SaveUser();
            MessageBox.Show(posted);
            txtEmail.Text = "";
            txtName.Text = "";
        }
    }
}
