﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public interface IDataStore
    {
        Task<T> GetUsersAsync<T>(string username = null);
        Task<string> PostUserAsync(User user);
    }
}
