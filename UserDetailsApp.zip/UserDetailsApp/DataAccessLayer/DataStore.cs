﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public class DataStore : IDataStore
    {
        private readonly ApiCallHelper clientHelper = new ApiCallHelper();
        private string url = "https://gorest.co.in/public/v2/users";

        public async Task<string> PostUserAsync(User user)
        {
            return await clientHelper.PostUserAsync<User>(user);
        }

        public async Task<T> GetUsersAsync<T>(string username = null)
        {
           return await clientHelper.GetUsersAsync<T>(username);
        }

    }
}
