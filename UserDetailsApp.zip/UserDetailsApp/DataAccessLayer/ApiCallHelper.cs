﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public class ApiCallHelper
    {
        private readonly HttpClient client;// = new HttpClient();
        private const string url = "https://gorest.co.in/public/v2/users";
        private const string accessToken = "0bf7fb56e6a27cbcadc402fc2fce8e3aa9ac2b40d4190698eb4e8df9284e2023";

        public ApiCallHelper() {
            client = CreateHttpClientObject();
        }

        private HttpClient CreateHttpClientObject()
        {
            HttpClientHandler handler = new HttpClientHandler() { UseDefaultCredentials = false };
            HttpClient client = new HttpClient(handler);

            try
            {
                client.BaseAddress = new Uri(url);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + accessToken);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return client;
        }

        public async Task<T> GetUsersAsync<T>(string username = null)
        {
            var currentUrl = string.IsNullOrEmpty(username) ? url : $"{url}?first_name={username}";
            var data = await client.GetStringAsync(url);
            return JsonConvert.DeserializeObject<T>(data);
        }
        public async Task<string> PostUserAsync<T>(User user)
        {
            string json = JsonConvert.SerializeObject(user);   
            StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
            var response = await client.PostAsync(url, httpContent);
            
            if (!response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsStringAsync();
            }
            return "Posted user successfully";
        }
    }
}
